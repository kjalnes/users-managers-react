FS Weekend Project
- Express
- Sequelize
- Postgres
- React
- React router
