import React from 'react';

const Home = () => (
    <div className="well">
        Home Page
        <pre>
            FS Weekend Project | React | React-Router | Sequelize | Express | Postgres
        </pre>
    </div>
)

export default Home;
